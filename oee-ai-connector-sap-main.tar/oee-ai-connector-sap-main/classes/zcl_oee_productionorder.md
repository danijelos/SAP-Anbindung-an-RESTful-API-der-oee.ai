# Class: [ZCL_OEE_PRODUCTIONORDER](src/zcl_oee_productionorder.clas.abap)

In the "ZCL_OEE_PRODUCTIONORDER"-class there is everything related to production-orders.
There are some setters, getters and the POST and PATCH Request.
