# Class: [ZCL_OEE_DATABASE_COMMUNICATION](src/zcl_oee_database_communication.clas.abap)

In the "ZCL_OEE_DATABASE_COMMUNICATION"-class there are all database accesses bundled.
There are some mapping methods but also inserts and updates.
