# Class: [ZCL_OEE_POSITION](src/zcl_oee_position.clas.abap)

In the "ZCL_OEE_POSITION"-class there is everything related to positions.
There are some setters, getters and the POST and PATCH Request.
