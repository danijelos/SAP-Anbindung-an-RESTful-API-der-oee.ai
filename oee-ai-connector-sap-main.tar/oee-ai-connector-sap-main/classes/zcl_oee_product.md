# Class: [ZCL_OEE_PRODUCT](src/zcl_oee_product.clas.abap)

In the "ZCL_OEE_PRODUCT"-class there is everything related to products.
There are some setters, getters and the POST Request.
